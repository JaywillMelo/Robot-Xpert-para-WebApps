## Procedimentos para deploy da nova versão

1) Remover a Pasta Build na pasta web (onde foi feito o Deploy na Heroku)
2) Copiar a nova Build
3) Substituir a URL da API (produção para test)
4) Entrar na pasta Web pelo terminal
5) Adicionar, comitar e publicar as alterações

API Produção = https://bodytest-api.herokuapp.com


## Comandos para publicar na Heroku
git add .
git commit -m "publicando a versão 2.0.0"
git push heroku master
