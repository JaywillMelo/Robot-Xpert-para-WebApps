def obter_nome():
    return 'Fernando'